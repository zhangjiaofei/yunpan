module.exports = [
  {
    userName: process.env.TY_USER_NAME || "userName",
    password: process.env.TY_PASSWORD || "password",
  },
  {
    userName: process.env.TY_USER_NAME1,
    password: process.env.TY_PASSWORD1,
  },
  {
    userName: process.env.TY_USER_NAME2,
    password: process.env.TY_PASSWORD2,
  },
  {
    userName: process.env.TY_USER_NAME3,
    password: process.env.TY_PASSWORD3,
  },
  {
    userName: process.env.TY_USER_NAME4,
    password: process.env.TY_PASSWORD4,
  },
];
