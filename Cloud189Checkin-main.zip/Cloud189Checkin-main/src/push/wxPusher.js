module.exports = {
  appToken:
    process.env.WX_PUSHER_APP_TOKEN || "AT_OzwCik0QP4p4AQlKdO4jbgjWApTiWsJr",
  uid: process.env.WX_PUSHER_UID || "",
};
