module.exports = {
  sendKey: process.env.SENDKEY || '',
};
