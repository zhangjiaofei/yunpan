module.exports = {
  key: process.env.WECOM_BOT_KEY || '',
  telphone: process.env.WECOM_BOT_TELPHONE || '',
};
